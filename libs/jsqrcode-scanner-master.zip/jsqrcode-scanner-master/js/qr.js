function read(a)
{
    $("#qr-value").text(a);
}
    
qrcode.callback = read;