# JSQRCode Scanner

**DISCLAIMER:**  
This demo "application" is little more then a hack I had laying around after playing with jsqrcode a bit. It was pushed mostly to answer a question on stackoverflow.
  
JSQRCode Scanner is a demo of how you could build a QR code scanner in the browser. It makes use of [*jsqrcode*](https://github.com/LazarSoft/jsqrcode) and *getUserMedia*.

It has no tests, messy code, bugs and will probably crash. If you manage to get it working; try holding a QR code in front of your webcam to unveil the magic. I managed to get it working using the latest chrome canary build.

enjoy.


[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/asbjornenge/jsqrcode-scanner/trend.png)](https://bitdeli.com/free "Bitdeli Badge")

